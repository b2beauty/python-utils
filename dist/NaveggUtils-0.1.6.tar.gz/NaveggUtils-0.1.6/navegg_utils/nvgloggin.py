#!/usr/bin/python2.7

import time
import logging
import logging.handlers as handlers

FORMAT = '%(levelname)s - %(asctime)s - File:%(filename)r - Function:%(funcName)r - Line:%(lineno)d - Message: %(message)s'


#Não funciona rotate de log. Se um segundo arquivo de log superar o valor de tamanho permitido ele sobrescreve.
class SizedTimedRotatingFileHandler(handlers.TimedRotatingFileHandler):
    def __init__(self, filename, mode='a', maxBytes=0, backupCount=0, encoding=None,
                 delay=0, when='D', interval=1, utc=False):
        if maxBytes > 0:
            mode = 'a'
        handlers.TimedRotatingFileHandler.__init__(
            self, filename, when, interval, backupCount, encoding, delay, utc)
        self.maxBytes = maxBytes

    def shouldRollover(self, record):
        if self.stream is None:
            self.stream = self._open()
        if self.maxBytes > 0:
            msg = "%s\n" % self.format(record)
            self.stream.seek(0, 2)
            if self.stream.tell() + len(msg) >= self.maxBytes:
                return 1
        t = int(time.time())
        if t >= self.rolloverAt:
            return 1
        return 0

def log(logname,nofile=True):

    logger = logging.getLogger(logname)
    logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter(FORMAT)

    #StreamHandler
    sh = logging.StreamHandler()
    sh.setLevel(logging.DEBUG)
    sh.setFormatter(formatter)
    logger.addHandler(sh)

    #FileHandler
    if not nofile:
        fh = SizedTimedRotatingFileHandler(
                '%s.log' %logname,
                maxBytes=1024,
                backupCount=5,interval=10)
        fh.setFormatter(formatter)
        logger.addHandler(fh)

    return logger

